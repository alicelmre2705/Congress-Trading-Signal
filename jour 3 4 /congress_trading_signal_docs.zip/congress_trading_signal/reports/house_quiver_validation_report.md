# House vs Quiver validation

Generated at: `2026-06-23T16:09:37+00:00`

## Rule
House XML + PDF remains the canonical source. Quiver is used only as an external sanity-check.

## Quiver access
- Status: `ok`
- Accessible version: `V2`
- Endpoint: `/beta/bulk/congresstrading`

## 2025 coverage metrics
- timestamp: `2026-06-23T16:09:37+00:00`
- n_house_ptr_filings_2025: `515`
- n_quiver_house_transactions_2025: `12527`
- n_unique_house_declarants_2025: `108`
- n_unique_quiver_declarants_2025: `84`
- overlap_declarants_count: `80`
- house_only_declarants_count: `28`
- quiver_only_declarants_count: `4`
- house_disclosure_date_min: `2025-01-01 00:00:00`
- house_disclosure_date_max: `2026-01-16 00:00:00`
- quiver_disclosure_date_min: `2025-01-06 00:00:00`
- quiver_disclosure_date_max: `2025-12-29 00:00:00`

## Interpretation
- A Quiver mismatch is not automatically a House error.
- No transaction-level match is claimed at this stage.
